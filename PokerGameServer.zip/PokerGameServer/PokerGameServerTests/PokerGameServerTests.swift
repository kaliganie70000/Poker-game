//
//  PokerGameServerTests.swift
//  PokerGameServerTests
//
//  Created by Antoine roy on 21/08/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import XCTest
@testable import PokerGameServer

class PokerGameServerTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        
        super.tearDown()
    }
    
    func testModelDeck() {
        let deck1: Deck = Deck()
        let deck2: Deck = Deck()
        
        deck1.resetDeck()
        deck1.shuffle()
        deck2.resetDeck()
        deck2.shuffle()
        XCTAssertNotEqual(deck1.deck, deck2.deck)
    }
    
    func testXMLMaker() {
        let maker: XMLMaker = XMLMaker(header: "test1")
        let maker2: XMLMaker = XMLMaker(header: "test2")
        
        XCTAssertNotEqual(maker.header!, maker2.header!)
        
        maker2.header = maker.header
        let obj: XMLObject = XMLObject(elems: ["nothing":"nothing"], header: "player")
        XCTAssertEqual(maker.toString(), maker2.toString(), "content equal")
        maker.addXML(obj)
        
        XCTAssertNotEqual(maker.toString(), maker2.toString())
        maker2.addXML(obj)
        XCTAssertEqual(maker.toString(), maker2.toString())

    }
    
    func testParserXMLResponse() {
        let maker: XMLMaker = XMLMaker(header: "test1")
        let obj: XMLObject = XMLObject(header: "player")
        
        let parser: XMLParser = XMLParser(xml: maker.toResponse(obj.toResponse("done")))
        XCTAssertEqual(parser.objects[0].response, "<done>")

    }

    func testParserXMLObject() {
        let maker: XMLMaker = XMLMaker(header: "test1")
        let obj: XMLObject = XMLObject(elems: ["nothing":"nothing"], header: "player")
        let obj2: XMLObject = XMLObject(elems: ["nothing":"nothing"], header: "player")

        maker.addXML(obj)
        maker.addXML(obj2)
        let parser: XMLParser = XMLParser(xml: maker.toString())
        XCTAssertEqual(parser.cmd!, "test1")
        for p in parser.objects {
            XCTAssertEqual(p.header!, "player")
        }
    }
    
    func testSolver() {
        let hand1: [Card] = [Card(number: "5", type: "spades"), Card(number: "6", type: "spades")]
        let hand2: [Card] = [Card(number: "2", type: "hearts"), Card(number: "ace", type: "clubs")]
        let hand3: [Card] = [Card(number: "jack", type: "diamonds"), Card(number: "queen", type: "diamonds")]
        let hand4: [Card] = [Card(number: "jack", type: "spades"), Card(number: "queen", type: "hearts")]
        
        let center: [Card] = [Card(number: "jack", type: "clubs"), Card(number: "queen", type: "spades"), Card(number: "ace", type: "hearts"), Card(number: "queen", type: "clubs"), Card(number: "5", type: "diamonds")]
        
        let res1 = SolverResult.solver(hand1, centrals: center)
        let res2 = SolverResult.solver(hand2, centrals: center)
        let res3 = SolverResult.solver(hand3, centrals: center)
        let res4 = SolverResult.solver(hand4, centrals: center)
        
        XCTAssertTrue((res1 < res2))
        XCTAssertTrue((res3 > res2))
        XCTAssertTrue((res4 == res3))

    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
}
