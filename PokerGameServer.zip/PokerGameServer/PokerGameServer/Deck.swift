//
//  Deck.swift
//  PokerGameServer
//
//  Created by Antoine roy on 28/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import Cocoa

class Deck: NSObject {

    var deck: [Card] = []
    var tabNumbers: [String] = ["ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king"]
    var tabTypes: [String] = ["diamonds", "hearts", "clubs", "spades"]
    
    func resetDeck() {
        //create the deck with all cards
        deck.removeAll()
        for type in tabTypes {
            
            for num in tabNumbers {
                
                deck.append(Card(number: num, type: type))
                
            }
            
        }
    }
    
    //Fisher-Yates algorithm
    func shuffle() {
        var i = deck.count - 1
        repeat {
            let random = Int(arc4random_uniform(UInt32(i - 1)))
            swap(&deck[i], &deck[random])
            
            i -= 1
        } while i > 0
        
        print("end shuffling:\n\(toString())\n\n")
    }
    
    func toString() -> String {
        //convert the deck object to a string
        var str = ""
        for card in deck {
            str += card.nameStr
            str += ", "
        }
        
        return str
        
    }
    
}
