//
//  XMLParser.swift
//  PokerGameClient
//
//  Created by Antoine roy on 20/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import Foundation

//parse the data receive from a client or the server
class XMLParser: NSObject {

    var cmd: String?
    var objects: [XMLObject] = []
    
    
    init(xml: String, response: Bool) {
        super.init()
        
        var tab: [String] = xml.characters.split{$0 == "\n"}.map(String.init)
        
        self.cmd = String(String(tab[0].characters.dropFirst()).characters.dropLast())
        
        print("\n\n commande: \(self.cmd!)")

        tab.removeLast()
        tab.removeFirst()

        if tab.isEmpty == true {
            return
        } else {
            if response == false {
                parseContent(tab)
            } else {
                parseResponse(tab)
            }
        }
        
    }
    
    init(xml: String) {
        super.init()
        //init the parser by the string received
        var tab: [String] = xml.characters.split{$0 == "\n"}.map(String.init)
        
        self.cmd = String(String(tab[0].characters.dropFirst()).characters.dropLast())
        print("\n\n commande: \(self.cmd!)")
        
        tab.removeLast()
        tab.removeFirst()
        //check if the data is a response or a normal request
        if self.cmd == "update" {
            parseContent(tab)
        } else {
            parseResponse(tab)
        }
    }
    
    override init() {
        super.init()
        
        cmd = ""
        objects = []
    }
    
    func generateEndHeader(header: String) -> String {
        var endHeader: String = header
        
        endHeader.insert("\\", atIndex: header.startIndex.advancedBy(1))
        
        return endHeader
    }
    
    func unWrapRequest(elems: [String], header: String) -> XMLObject {
        print("unwrap object of type \(header):")
        print(elems)
        
        var dic: [String: String] = [:]
        //loop on each line of the request
        for elem in elems {
            //save the key and value
            var tab = elem.characters.split{$0 == ":"}.map(String.init)
            let str = String(String(tab[0].characters.dropLast()).characters.dropFirst())
            dic[str] = tab[1]
        }
        print("\n\n\n")
        let objRet: XMLObject = XMLObject(elems: dic, header: header)
        return objRet
    }
    
    func unWrapResponse(elem: String, header: String) -> XMLObject {
        let xmlobj: XMLObject = XMLObject(response: elem, header: header)
        print("object response: \(xmlobj)")
        return xmlobj
    }
    
    func isBalise(str: String) -> Bool {
        let tab: [String] = str.characters.split{$0 == ":"}.map(String.init)
        var isBalise: Bool = false
        
        if tab.count == 1 {
            isBalise = true
        }
        
        return isBalise
    }
    
    func parseObject(strs: [String], header: String) -> (XMLObject, [String]) {
        var tabStr: [String] = strs
        let endHeader = generateEndHeader(header)
        let headerObj = String(String(header.characters.dropFirst()).characters.dropLast())
        var elems: [String] = []
        
        tabStr.removeFirst()
        repeat {
            elems.append(tabStr[0])
            tabStr.removeFirst()
        } while tabStr[0] != endHeader
        
        let obj = unWrapRequest(elems, header: headerObj)
        tabStr.removeFirst()
        
        return (obj, tabStr)
    }
    
    func parseContent(tab: [String]) {
        
        var strs: [String] = tab
        var objects: [XMLObject] = []
        //loop on each line of the data and parse all key and objects
        repeat {
            var headerObj = strs[0]
            
            strs.removeFirst()
            let endHeader = generateEndHeader(headerObj)
            headerObj = String(String(headerObj.characters.dropFirst()).characters.dropLast())

            
            if strs.indexOf(endHeader) != nil {
                
                var elem: [String] = []
                
                var includedObj: [XMLObject] = []
                
                repeat {
                    
                    if isBalise(strs[0]) == true {

                        let (obj, tab) = parseObject(strs, header: strs[0])
                        strs = tab
                        includedObj.append(obj)
                        
                    } else {
                    
                        elem.append(strs[0])
                        strs.removeFirst()
                    
                    }
                    
                } while strs.isEmpty == false && strs[0] != endHeader
                let appObj = unWrapRequest(elem, header: headerObj)
                appObj.objects = includedObj
                objects.append(appObj)
                strs.removeFirst()
                
            } else {
                print("no header")
            }
            
        } while strs.isEmpty == false
        
        self.objects = objects
    }
    
    func parseResponse(tab: [String]) {
        var strs: [String] = tab
        print("response: \n\(tab)")
        
        
        var headerObj = strs[0]
        headerObj = String(String(headerObj.characters.dropFirst()).characters.dropLast())

        
        strs.removeLast()
        strs.removeFirst()
        
        print("strs[0]: \(strs[0])")
        self.objects.append(unWrapResponse(strs[0], header: headerObj))
        print("yolo")
    }
    
}
