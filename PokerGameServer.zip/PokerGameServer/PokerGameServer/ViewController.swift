//
//  ViewController.swift
//  PokerGameServer
//
//  Created by Antoine roy on 16/06/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import Cocoa
import SceneKit
import QuartzCore

class ViewController: NSViewController {

    @IBOutlet weak var labelInfo: NSTextField!
    @IBOutlet weak var btnConnection: NSButton!
    @IBOutlet weak var IpTextField: NSTextField!
    @IBOutlet weak var portTextField: NSTextField!
    
    var serverState: Bool = false
    let server: Server = Server()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        refreshIP(0)

    }

    override var representedObject: AnyObject? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    @IBAction func ConnectDisconnect(sender: AnyObject) {
        let threadServer = NSThread.init(target: self, selector: #selector(ViewController.threadConnection), object: nil)
        //change the button of connection + start or stop the server
        if serverState == false {
            serverState = true
            btnConnection.image = NSImage(named: "btnDisconnect")
            labelInfo.hidden = true
            print("connection....")
            threadServer.start()
        } else {
            serverState = false
            btnConnection.image = NSImage(named: "btnConnect")
            labelInfo.hidden = false
            server.closeServer()
            for t in server.tables {
                t.deleteAllClient()
            }
            server.tables.removeAll()
            threadServer.cancel()
        }
    }
    
    @IBAction func refreshIP(sender: AnyObject) {
        //refresh the IP label
        let values = Utils().getIFAddresses()
        
        if !values.isEmpty && !values[0].isEmpty {
            print(values[0])
            IpTextField.stringValue = values[0]
            //IpTextField.font = NSFont(name: "Arial", size: 27)
        } else {
            IpTextField.stringValue = "No connection!"
            //IpTextField.font = NSFont(name: "Arial", size: 27)
        }
    }
    
    func threadConnection() {
        print("coucou")
        //launch the server.
        server.launchServer(IpTextField.stringValue, port: 8080)
    }
    
}

