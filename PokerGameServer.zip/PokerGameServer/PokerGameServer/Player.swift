//
//  Player.swift
//  PokerGameServer
//
//  Created by Antoine roy on 25/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import Foundation

class Player: TCPClient {
    //all data of a player
    var money: Int?
    var sit: Int?
    var cards: [Card] = []
    var bigBlind: Bool = false
    var smallBlind: Bool = false
    var isDealer: Bool = false
    var moneyBet: Int?
    var isPlaying: Bool = false
    var bettingTurn: Bool = false
    var folded: Bool = false
    var score: Int = 0
    
    override init() {
        super.init()
        
        money = 0
        sit = -1
        id = 0
    }
    
    init(client: TCPClient) {
        super.init()
        self.fd = client.fd
        self.port = client.port
        self.addr = client.addr
        self.nickname = client.nickname
        self.id = client.id
    }
    
    init(obj: XMLObject) {
        super.init()
        //init the object with a XMLObject
        if let id = obj.object["id"] {
            self.id = Int(id)
        }
        
        if let money = obj.object["money"] {
            self.money = Int(money)
        }
        
        if let sit = obj.object["sit"] {
            self.sit = Int(sit)
        }
        
        if let card1 = obj.object["card1"] {
            cards.append(Card(name: card1))
        }
         
        if let card2 = obj.object["card2"] {
            cards.append(Card(name: card2))
        }
        
        if let isPlaying = obj.object["isPlaying"] {
            if Int(isPlaying) == 0 {
               self.isPlaying = false
            } else {
                self.isPlaying = true
            }
        }
        
        if let bettingTurn = obj.object["bettingTurn"] {
            if Int(bettingTurn) == 0 {
                self.bettingTurn = false
            } else {
                self.bettingTurn = true
            }
        }
        
        if let folded = obj.object["folded"] {
            if Int(folded) == 0 {
                self.folded = false
            } else {
                self.folded = true
            }
        }
        
    }
    
    func getDicObject() -> [String: String] {
        //convert the object to a dictionary
        var dic: [String : String] = [:]
        
        dic["money"] = "0"
        dic["sit"] = "-1"
        dic["name"] = nickname!
        if self.id != nil {
            dic["id"] = "\(self.id!)"
        } else if self.fd != nil {
            dic["id"] = "\(self.fd!)"
        }
        
        if self.money != nil {
            dic["money"] = "\(self.money!)"
        }
        if self.sit != nil {
            dic["sit"] = "\(self.sit!)"
        }
        
        if cards.isEmpty == false {
            dic["card1"] = cards[0].nameStr
            dic["card2"] = cards[1].nameStr
        }
        
        dic["bb"] = "0"
        if bigBlind == true {
            dic["bb"] = "1"
        }
        dic["sb"] = "0"
        if smallBlind == true {
            dic["sb"] = "1"
        }
        dic["dealer"] = "0"
        if isDealer == true {
            dic["dealer"] = "1"
        }
        
        if moneyBet != nil {
            dic["moneyBet"] = "\(moneyBet!)"
        }
        
        dic["isPlaying"] = "0"
        if isPlaying == true {
            dic["isPlaying"] = "1"
        }
        
        dic["bettingTurn"] = "0"
        if bettingTurn == true {
            dic["bettingTurn"] = "1"
        }
        
        dic["folded"] = "0"
        if folded == true {
            dic["folded"] = "1"
        }
        
        return dic
    }
    
}
