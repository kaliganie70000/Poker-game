//
//  Player.swift
//  PokerGameClient
//
//  Created by Antoine roy on 14/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class Player: Client {
    //all information about a player
    var money: Int?
    var cards: [Card] = []
    var sit: Int?
    var bigBlind: Bool = false
    var smallBlind: Bool = false
    var isDealer: Bool = false
    var moneyBet: Int?
    var isPlaying: Bool = false
    var bettingTurn: Bool = false
    var folded: Bool = false
    
    override init() {
        super.init()
        
        money = 0
        sit = -1
    }
    
    init(client: Client) {
        super.init()
        self.fd = client.fd
        self.port = client.port
        self.addr = client.addr
        self.nickname = client.nickname
        self.id = client.id
    }
    
    init(obj: XMLObject) {
        super.init()
        //init a player by a XMLObject
        if let name = obj.object["name"] {
            self.nickname = name
        }
        
        if let money = obj.object["money"] {
            self.money = Int(money)
        }
        
        if let sit = obj.object["sit"] {
            self.sit = Int(sit)
        }
        
        if let id = obj.object["id"] {
            self.id = Int(id)
        }
        
        if let card1 = obj.object["card1"] {
            cards.append(Card(str: card1))
        }
        
        if let card2 = obj.object["card2"] {
            cards.append(Card(str: card2))
        }
        
        if let sb = obj.object["sb"] {
            if Int(sb) == 0 {
                self.smallBlind = false
            } else {
                self.smallBlind = true
            }
        }
        
        if let bb = obj.object["bb"] {
            if Int(bb) == 0 {
                self.bigBlind = false
            } else {
                self.bigBlind = true
            }
        }
        
        if let dealer = obj.object["dealer"] {
            if Int(dealer) == 0 {
                self.isDealer = false
            } else {
                self.isDealer = true
            }
        }
        
        if let moneyBet = obj.object["moneyBet"] {
            self.moneyBet = Int(moneyBet)
        }
        
        if let isPlaying = obj.object["isPlaying"] {
            if Int(isPlaying) == 0 {
                self.isPlaying = false
            } else {
                self.isPlaying = true
            }
        }

        if let bettingTurn = obj.object["bettingTurn"] {
            if Int(bettingTurn) == 0 {
                self.bettingTurn = false
            } else {
                self.bettingTurn = true
            }
        }
        
        if let folded = obj.object["folded"] {
            if Int(folded) == 0 {
                self.folded = false
            } else {
                self.folded = true
            }
        }
        
    }
    
    func getDicObject() -> [String: String] {
        var dic: [String : String] = [:]
        //get all information about the player in a dictionary
        dic["money"] = "\(self.money!)"
        dic["name"] = self.nickname
        if self.cards.isEmpty == false {
            dic["card1"] = self.cards[0].nameStr
            dic["card2"] = self.cards[1].nameStr
        }
        dic["sit"] = "\(self.sit!)"
        
        if self.id != nil {
            dic["id"] = "\(self.id!)"
        }
        
        dic["bb"] = "0"
        if bigBlind == true {
            dic["bb"] = "1"
        }
        dic["sb"] = "0"
        if smallBlind == true {
            dic["sb"] = "1"
        }
        dic["dealer"] = "0"
        if isDealer == true {
            dic["dealer"] = "1"
        }
        
        if moneyBet != nil {
            dic["moneyBet"] = "\(moneyBet!)"
        }
        
        dic["isPlaying"] = "0"
        if isPlaying == true {
            dic["isPlaying"] = "1"
        }

        dic["bettingTurn"] = "0"
        if bettingTurn == true {
            dic["bettingTurn"] = "1"
        }
        
        dic["folded"] = "0"
        if folded == true {
            dic["folded"] = "1"
        }
        
        return dic
    }

}
