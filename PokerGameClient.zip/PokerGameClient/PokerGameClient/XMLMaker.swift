//
//  XMLMaker.swift
//  PokerGameClient
//
//  Created by Antoine roy on 18/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import Foundation

class XMLMaker: NSObject {

    var tabXML: [XMLObject] = []
    var header: String?
    
    
    init(header: String) {
        self.header = header
    }
    
    func getHeaderTop() -> String {
        return "<\(header!)>\n"
    }
    
    func getHeaderEnd() -> String {
        return "<\\\(header!)>"
    }
    
    
    
    func addXML(obj: XMLObject, pos: Int = -1) {
        //add a XMLObject to the list
        if pos == -1 {
            tabXML.append(obj)
        } else {
            tabXML.insert(obj, atIndex: pos)
        }
    }
    
    func addMultipleXML(objs: [XMLObject]) {
        //can add multiple objects to the list
        for obj in objs {
            tabXML.append(obj)
        }
    }
    
    func removeXML(pos: Int) {
        //remove one object from the list
        tabXML.removeAtIndex(pos)
    }
    
    
    func toString() -> String {
        //convert the maker to a string
        var strXML: String
        
        strXML = getHeaderTop()
        for obj in tabXML {
            strXML += obj.toString()
        }
        strXML += getHeaderEnd()
        
        
        return strXML
    }
    
    func toResponse(obj: String) -> String{
        //convert the maker to a string with a response architecture
        var strXML: String
        
        strXML = getHeaderTop()
        strXML += obj
        strXML += getHeaderEnd()
        
        return strXML
    }
    
}
