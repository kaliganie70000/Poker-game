//
//  Card.swift
//  PokerGameClient
//
//  Created by Antoine roy on 14/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class Card: NSObject {
    //simple card model.
    var nameStr: String?
    var img: UIImage?
    
    override init() {
        super.init()
        nameStr = ""
    }
    
    init(str: String) {
        super.init()
        self.nameStr = str
        img = UIImage(named: nameStr!)
    }
    
    
}