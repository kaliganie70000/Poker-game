//
//  PopUpView.swift
//  PokerGameClient
//
//  Created by Antoine roy on 24/06/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class PopUpView: UIView {

    @IBOutlet weak var tableNameField: UITextField!
    @IBOutlet weak var blindLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var playersField: UITextField!
    
    @IBOutlet weak var createTableBtn: UIButton!
    
    var state: Bool = false
    let blindsString: [String] = ["small blind", "medium blind", "high blind"]
    
    class func instanceFromNib() -> PopUpView {
        
        //init the view.
        
        return UINib(nibName: "PopUpView", bundle: nil).instantiateWithOwner(nil, options: nil)[0] as! PopUpView
        
    }
    
    @IBAction func showListBlind(sender: AnyObject) {
        if state == false {
            state = true
            tableView.hidden = false
        } else {
            state = false
            tableView.hidden = true
        }
    }
    
    func initContent() {
        //init the view
        tableView.registerNib(UINib(nibName: "LabelTableViewCell", bundle: nil), forCellReuseIdentifier: "LabelCellIdentifier")
    }
    
    @IBAction func cancelCreateTable(sender: AnyObject) {
        print(self.frame.size)
        //the button cancel has been click, hide the pop-up view
        UIView.animateWithDuration(2, animations: {
            
            self.frame = CGRectMake((UIScreen.mainScreen().bounds.width / 2) - 150, UIScreen.mainScreen().bounds.height, 300, 380)
            
            }, completion: { Void in
                
            self.hidden = true
            
        })
    }

    func getValueOfBlind() -> Int {
        var i = 0
        repeat {
            if blindLabel.text == blindsString[i] {
                return i
            }
            i += 1
        } while i < blindsString.count
        
        return -1
    }
    
    @IBAction func lessPlayer(sender: AnyObject) {
        var value: Int = Int(playersField.text!)!
        if value > 2 {
            value -= 1
        }
        playersField.text = "\(value)"
    }
    
    @IBAction func morePlayer(sender: AnyObject) {
        var value: Int = Int(playersField.text!)!
        if value < 8 {
            value += 1
        }
        playersField.text = "\(value)"
    }
    
    
}
