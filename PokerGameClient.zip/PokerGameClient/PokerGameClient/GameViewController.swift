//
//  GameViewController.swift
//  PokerGameClient
//
//  Created by Antoine roy on 14/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class GameViewController: UIViewController {

    //origin table when created
    var table: GamingTable?
    //All attributes for the graphical part
    var tableImage: UIImageView?
    var labelPot: UILabel?
    var tabBtnPlayer: [PlayerView] = []
    var tabMoneyPlayer: [UILabel] = []
    var tabImgDealer: [UIImageView] = []
    var centralCards: [UIImageView] = []
    var actionsView: ActionsView?
    //latest data of the table from the server
    var theTable: XMLObject?
    var threadClient: NSThread?
    var letRead: Bool = true
    let clock: DDHTimerControl = DDHTimerControl(type: .Solid)
    var timer = NSTimer()
    var played: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set the orientation of the device
        if UIDevice.currentDevice().userInterfaceIdiom == .Pad {
            UIDevice.currentDevice().setValue(UIInterfaceOrientation.Portrait.rawValue, forKey: "orientation")
        } else {
            UIDevice.currentDevice().setValue(UIInterfaceOrientation.LandscapeLeft.rawValue, forKey: "orientation")
        }
 
        self.view.frame = CGRectMake(0, 0, UIScreen.mainScreen().bounds.width, UIScreen.mainScreen().bounds.height)
        
        print("size device: \(UIScreen.mainScreen().bounds.size)")

        var smallSize = UIScreen.mainScreen().bounds.size.width
        var bigSize = UIScreen.mainScreen().bounds.size.height
        if smallSize > UIScreen.mainScreen().bounds.size.height {
            smallSize = UIScreen.mainScreen().bounds.size.height
            bigSize = UIScreen.mainScreen().bounds.size.width
        }
        
        //set the image of the table
        self.tableImage = UIImageView(frame: CGRectMake(0, 0, smallSize, smallSize))
        self.tableImage!.image = UIImage(named: "poker_table")
        self.view.backgroundColor = UIColor.greenColor()
        self.view.addSubview(self.tableImage!)
        
        //set sit of players
        setBtnPlayer((table?.maxPlayers)!)
        
        //set the view with all actions
        self.setActionsView(smallSize, bigSize: bigSize)

    }
    
    override func viewDidAppear(animated: Bool) {
        //check if a game is running to set the clock and player's turn
        if theTable != nil && theTable?.object["running"] == "1" {
            setClock()
        }
        
        //check if a  player has to bet at the beginning of the turn
        if theTable != nil {
            doAutomaticBbSb()
        }
        
        //initialise and start the thread to read on the socket.
        threadClient = NSThread.init(target: self, selector: #selector(GameViewController.threadClientFct), object: nil)
        threadClient!.start()
    }
    
    func doAutomaticBbSb() {
        //check if the server just dealed the cards to all players
        var dealed = false
        if theTable?.object["dealed"] == "1" {
            dealed = true
        }
        
        //loop on each player in the variable theTable.
        for p in theTable!.objects {
            print("header: \(p.header)")
            //check if the header of the object is a player
            if p.header! == "player" {
                //init an player object by using a XMLObject
                let player: Player = Player(obj: p)
                
                print("------------->checking after update: dealed \(dealed), user.sit \(self.table?.user?.sit!) == player.sit \(player.sit!), betting turn \(player.bettingTurn)")
                
                print("verif for DISABLE: user.sit == \(self.table?.user?.sit!) -> p.sit == \(player.sit!); betting turn? \(player.bettingTurn)")
                //check if it's this player's turn, if not, disable all betting actions
                if self.table?.user?.sit! == player.sit! && player.bettingTurn == false {
                    print("verif ok !!!")
                    disableAllAction()
                }
                
                //check if the server just dealed and if it's player's turn.
                if dealed == true && (player.moneyBet == nil || player.moneyBet! == 0) && self.table?.user?.sit! == player.sit! && player.bettingTurn == true {
                    print("checking done is bb \(player.bigBlind) or sb \(player.smallBlind)")
                    //check if the player is small blind or big blind, to execute an automatic bet.
                    if player.bigBlind == true {
                        manualCallRequest(Int(theTable!.object["bb"]!)!)
                    } else if player.smallBlind == true {
                        manualCallRequest(Int(theTable!.object["sb"]!)!)
                    }
                }

            }
            
        }
        //update the content of the labels
        updateMoneyLabel()
    }
    
    func updateMoneyLabel() {
        //loop in all player.
        for p in theTable!.objects {
            if p.header! == "player" {
                let player: Player = Player(obj: p)
                
                //check if the player already bet during this turn, if yes, set the label.
                if player.moneyBet != nil && player.moneyBet! > 0 {
                    tabMoneyPlayer[player.sit!].text = "\(player.moneyBet!)"
                }
            }
        }
        
        //check if the server says that it's the end of the betting round (doesn't work).
        if theTable?.object["animBet"] == "1" {
            animAllMoney()
        }
    }
    
    func setActionsView(smallSize: CGFloat, bigSize: CGFloat) {
        //define the position of the view according by the type of the device.
        if UIDevice.currentDevice().userInterfaceIdiom == .Pad {
            actionsView = ActionsView(frame: CGRectMake(0, (tableImage?.frame.height)!, smallSize, bigSize - smallSize))
        } else {
            actionsView = ActionsView(frame: CGRectMake((tableImage?.frame.width)!, 0, bigSize - smallSize, smallSize))
        }
        
        //set start and leave actions manually.
        actionsView?.LeaveTableBtn.addTarget(self, action: #selector(GameViewController.leaveTable), forControlEvents: .TouchUpInside)
        actionsView?.startGameBtn.addTarget(self, action: #selector(GameViewController.startGame), forControlEvents: .TouchUpInside)
        
        print("check for btn start: \((self.table?.idCreator!)!) == \(self.table?.user?.id!)")
        //check if the player is the owner of the table, if not, hide the start button
        if (self.table?.idCreator!)! != self.table?.user?.id! {
            print("comparaison ids done !!")
            actionsView?.startGameBtn.hidden = true
        }

        if theTable != nil {
            //get the small blind value
            let sb: Int = Int((theTable?.object["sb"])!)!
            
            var maxbet: Int = 0
            //get the highest bet did on this betting round
            if let mb = theTable?.object["maxBet"] {
                maxbet = Int(mb)!
            }
        
            //set the content value of the view
            let value = sb + maxbet
            actionsView!.moneyLabel.text = "\(value)"
            actionsView!.pot = Int((theTable?.object["pot"])!)!
            actionsView?.slider.minimumValue = Float(sb)
            
            //check if the game already started, if yes, hide the button start
            if theTable?.object["started"] == "1" {
                actionsView?.startGameBtn.hidden = true
            }
            
            var max = 0
            //check all players to set the call button and the check/fold button.
            for p in (theTable?.objects)! {
                if p.header! == "player" {
                    let sit: Int = Int(p.object["sit"]!)!
                    if sit == self.table?.user?.sit! {
                        max = Int(p.object["money"]!)!
                        if let valMaxBet = p.object["moneyBet"] {
                            if maxbet == Int(valMaxBet) {
                                actionsView?.callBtn.hidden = true
                                actionsView?.checkFoldBtn.setTitle("Check", forState: .Normal)
                            }
                        }
                        
                        break
                    }
                }
            }
            //set raise button
            actionsView?.raiseBtn.setTitle("Raise to \(Int((actionsView?.slider.maximumValue)!))", forState: .Normal)
            actionsView?.slider.maximumValue = Float(max)
        }
  
        actionsView!.layer.borderWidth = 1
        actionsView!.tableNameLabel.text = "\(actionsView!.tableNameLabel.text!) \((self.table?.name!)!)"
        
        //set buttons target manually
        actionsView?.callBtn.addTarget(self, action: #selector(GameViewController.requestCall), forControlEvents: .TouchUpInside)
        actionsView?.raiseBtn.addTarget(self, action: #selector(GameViewController.requestRaise), forControlEvents: .TouchUpInside)
        actionsView?.checkFoldBtn.addTarget(self, action: #selector(GameViewController.requestCheckFold), forControlEvents: .TouchUpInside)

        //add the action view to the main view
        self.view.addSubview(self.actionsView!)
    }

    func setClock() {
        
        //the clock has been removed because of the delay of the server.
        //setting the player's turn label
        var frame: CGRect?
        if UIDevice.currentDevice().userInterfaceIdiom == .Pad {
            frame = CGRectMake((actionsView?.startGameBtn.frame.origin.x)!, (actionsView?.startGameBtn.frame.origin.y)!, (actionsView?.startGameBtn.frame.width)!, (actionsView?.startGameBtn.frame.height)!)
        } else {
            frame = CGRectMake((actionsView?.startGameBtn.frame.origin.x)!, (actionsView?.startGameBtn.frame.origin.y)!, (actionsView?.startGameBtn.frame.width)!, (actionsView?.startGameBtn.frame.height)!)
        }
        let label: UILabel = UILabel(frame: frame!)
        for obj in (theTable?.objects)! {
            if obj.header! == "player" && obj.object["bettingTurn"] == "1" {
                label.text = "\(obj.object["name"]!)'s turn"
                label.font = UIFont(name: label.font.fontName, size: 20)
            }
        }
        
        actionsView?.addSubview(label)
    }
    
    func disableAllAction() {
        //disable all actions fron the action view.
        actionsView?.checkFoldBtn.enabled = false
        actionsView?.callBtn.enabled = false
        actionsView?.raiseBtn.enabled = false
        timer.invalidate()
    }
    
    func update() {
        // update the value of the clock (disabled)
        if played == false {
            if self.clock.minutesOrSeconds > 0 {
                self.clock.minutesOrSeconds -= 1
                print("timer still working for tag: \(self.view.tag)")
            } else {
                //send a fold request when the player doesn't play on time (disabled)
                print("fin du chrono")
                timer.invalidate()
                for obj in (theTable?.objects)! {
                    if obj.header == "player" && table?.user?.sit! == Int(obj.object["sit"]!) && obj.object["bettingTurn"] == "1" {
                        requestCheckFold()
                    }
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func animAllMoney() {
        print("I'm here, it's good")
        //create animation to each label.
        for l in tabMoneyPlayer {
            
            let frame = l.frame
            UIView.animateWithDuration(1, animations: {
                
                l.frame = (self.labelPot?.frame)!
                
                }, completion: { Void in
                    l.frame = frame
                    l.text = "0"
            })
            
        }
    }
    
    func threadClientFct() {
        repeat {
            //init the timer
            timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: #selector(GameViewController.update), userInfo: nil, repeats: true)
            
            //read on the socket
            let parser: XMLParser = (table?.user?.gamingReading())!
            
            //check the command receive by the server
            switch parser.cmd! {
            case "update":
                print("commande update")
                theTable = parser.objects[0]
                timer.invalidate()
                tabBtnPlayer[0].boutonCaca.sendActionsForControlEvents(UIControlEvents.TouchUpInside)
            case "start":
                if parser.objects[0].response == "<fail>" {

                }
            case "leave":
                if parser.objects[0].response == "<fail>" {
                    
                } else {
                    let vc = topMostController()
                    
                    self.table?.user?.close()
                    self.threadClient?.cancel()
                    letRead = false
                    let MainStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let mainVc = MainStoryboard.instantiateViewControllerWithIdentifier("ConnectionIdentifier") as? ConnectionViewController
                    timer.invalidate()
                    mainVc?.view.tag = self.view.tag + 1
                    vc.presentViewController(mainVc!, animated: true, completion: nil)
                }
            case "sit":
                if parser.objects[0].response == "<done>" {
                    print("sitting done")
                    
                    for sit in tabBtnPlayer {
                        sit.btn.hidden = true
                        
                    }
                    
                } else {
                    print("sitting failed")     
                }
            case "central":
                let central : XMLObject = parser.objects[0]
                var i = 0
                for card in centralCards {
                    if (central.object.count) - 1 >= i {
                        print("central card \(i) : \(central.object["card\(i)"])")
                        card.image = UIImage(named: (central.object["card\(i)"])!)
                    } else {
                        card.image = UIImage(named: "backCard")
                    }
                    i += 1
                }
            case "call":
                let p: XMLObject = parser.objects[0]
                print("update Call")
                tabMoneyPlayer[Int(p.object["sit"]!)!].text = "\(p.object["moneyBet"]!)"
            default: break
            }
            
            timer.invalidate()
            if letRead == false {
                print("letRead == false")
                let vc = topMostController()
                
                let MainStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let mainVc = MainStoryboard.instantiateViewControllerWithIdentifier("ConnectionIdentifier") as? ConnectionViewController
                vc.presentViewController(mainVc!, animated: true, completion: nil)

            }
        } while letRead == true
    }
    
    func topMostController() -> UIViewController {
        //get the main controller of the application
        var topController: UIViewController = UIApplication.sharedApplication().keyWindow!.rootViewController!
        while (topController.presentedViewController != nil) {
            topController = topController.presentedViewController!
        }
        return topController
    }
    
    func updateTable() {
        
        print("--------------UPDATEEEEEEEE-------------")
        
        print("\nthere are \(theTable!.objects.count) players in the tab\n")
        print("content: \(theTable!.object)")
        
        //reset all the view controller.
        dispatch_async(dispatch_get_main_queue(), {
            self.view.translatesAutoresizingMaskIntoConstraints = true
            let GameStoryboard = UIStoryboard(name: "Game", bundle: nil)
            let GameVc = GameStoryboard.instantiateViewControllerWithIdentifier("GameViewControllerId") as? GameViewController
            GameVc!.table = self.table
            GameVc!.theTable = self.theTable
            GameVc?.view.frame = self.view.frame
            GameVc?.view.translatesAutoresizingMaskIntoConstraints = true
            self.timer.invalidate()
            GameVc?.view.tag = self.view.tag + 1
            self.threadClient?.cancel()
            self.topMostController().presentViewController(GameVc!, animated: false, completion: nil)
        })
        
    }
    
    func setCentralCards() {
        let ratio: CGFloat = 1.48
        let space: CGFloat = 10
        let sizeCard: CGFloat = tabBtnPlayer[0].frame.width / 2
        
        //create the 5 central cards
        centralCards.append(UIImageView(frame: CGRectMake(((tableImage?.frame.width)! / 2) - (2 * space) - (CGFloat(2.5) * sizeCard), ((tableImage?.frame.height)! / 2) - ((sizeCard * ratio) / 2), sizeCard, sizeCard * ratio)))
        
        centralCards.append(UIImageView(frame: CGRectMake(((tableImage?.frame.width)! / 2) - (1 * space) - (CGFloat(1.5) * sizeCard), ((tableImage?.frame.height)! / 2) - ((sizeCard * ratio) / 2), sizeCard, sizeCard * ratio)))
        
        centralCards.append(UIImageView(frame: CGRectMake(((tableImage?.frame.width)! / 2) - (0 * space) - (CGFloat(0.5) * sizeCard), ((tableImage?.frame.height)! / 2) - ((sizeCard * ratio) / 2), sizeCard, sizeCard * ratio)))
        
        centralCards.append(UIImageView(frame: CGRectMake(((tableImage?.frame.width)! / 2) + (1 * space) + (CGFloat(0.5) * sizeCard), ((tableImage?.frame.height)! / 2) - ((sizeCard * ratio) / 2), sizeCard, sizeCard * ratio)))
        
        centralCards.append(UIImageView(frame: CGRectMake(((tableImage?.frame.width)! / 2) + (2 * space) + (CGFloat(1.5) * sizeCard), ((tableImage?.frame.height)! / 2) - ((sizeCard * ratio) / 2), sizeCard, sizeCard * ratio)))
        
        
        var i = 0
        var central: XMLObject?
        //check if the server already sent central cards to update the images
        //if there is no images, set the back of the card
        if theTable != nil {
            for obj in (theTable?.objects)! {
                if obj.header! == "centralCards" {
                    central = obj
                    break
                }
            }
        }
        if central != nil {
            print("nb central cards : \(central?.object.count)")
        }
        for card in centralCards {
            if theTable != nil && central != nil && (central?.object.count)! - 1 >= i {
                print("central card \(i) : \(central?.object["card\(i)"])")
                card.image = UIImage(named: (central?.object["card\(i)"])!)
            } else {
                card.image = UIImage(named: "backCard")
            }
            card.layer.borderWidth = 0.4
            card.layer.cornerRadius = 3
            self.view.addSubview(card)
            i += 1
        }
    }
    
    func setPotMoney() {
        //change the value of the pot label.
        labelPot = UILabel(frame: CGRectMake((tableImage!.frame.width / 2) - centralCards[1].frame.width, centralCards[2].frame.origin.y + centralCards[0].frame.height + 10, centralCards[1].frame.width * 2, 20))
        
        if theTable != nil && theTable?.object["pot"] != nil {
            let pot: Int = Int((theTable?.object["pot"])!)!
            labelPot?.text = "\(pot)$"
        }
        
        labelPot?.textColor = UIColor.whiteColor()
        labelPot?.textAlignment = .Center
        self.view.addSubview(labelPot!)
    }
    
    func setBtnPlayer(nbPlayers: Int) {
        
        var i = 0
        repeat { //create a sit for each players
            let (points, sizes) = getFrameBtn(i)
            let (p, s) = getFrameDealer(i)
            let (lp, ls) = getFrameMoney(i)
            
            //load a player view
            let btn: PlayerView = PlayerView(frame: CGRectMake(points.x, points.y, sizes.width, sizes.height))
            let img: UIImageView = UIImageView(frame: CGRectMake(p.x, p.y, s.width, s.height))
            let label: UILabel = UILabel(frame: CGRectMake(lp.x, lp.y, ls.width, ls.height))
            
            img.image = UIImage(named: "dealer")
            label.text = ""
            label.textAlignment = .Center
            label.textColor = UIColor.whiteColor()
            
            tabBtnPlayer.append(btn)
            tabImgDealer.append(img)
            tabMoneyPlayer.append(label)
            
            //create the content of the player view
            tabBtnPlayer[i].createContent()
            
            tabBtnPlayer[i].btn.btnSit.tag = i
            tabBtnPlayer[i].btn.btnSit.addTarget(self, action: #selector(GameViewController.notificationSelectedBtn(_:)), forControlEvents: UIControlEvents.TouchUpInside)
            btn.boutonCaca.addTarget(self, action: #selector(GameViewController.updateTable), forControlEvents: .TouchUpInside)
            tabBtnPlayer[i].tag = i
            
            
            if theTable == nil {
                var isSelectable = true
                for p in (table?.listPlayers)! {
                    if p.sit != nil && p.sit == i {
                        isSelectable = false
                        tabBtnPlayer[i].updateContent(p, show: false)
                    }
                }
                
                if isSelectable == true {
                    tabBtnPlayer[i].setSelectable()
                }
            }
            
            tabMoneyPlayer[i].hidden = true
            tabImgDealer[i].hidden = true
            
            self.view.addSubview(tabBtnPlayer[i])
            self.view.addSubview(tabImgDealer[i])
            self.view.addSubview(tabMoneyPlayer[i])
            
            i += 1
        } while i < nbPlayers
        
        setCentralCards()
        setPotMoney()
        
        if theTable != nil {
            
            print("---------------THE TABLE IS NOT NIL----------------")
            
            var dealed = false
            //check if the server just dealed the cards to each player
            if theTable?.object["dealed"] == "1" {
                dealed = true
            }
            
            //loop to each player
            for p in theTable!.objects {
                print("header: \(p.header)")
                if p.header! == "player" {
                    print("comparaison done")
                    let player: Player = Player(obj: p)
                    var show: Bool = false
                    print("player : \(player.getDicObject())")
                    print("check ids -> user.id == \((table?.user?.id!)!) and player.fd == \(player.id!)")
                    if (table?.user?.id!)! == player.id! {
                        print("---------prepare to show ")
                        show = true
                    }
                    print("time to update sit \(player.sit!)\nthere are \(tabBtnPlayer.count) sits")
                
                    //set the money bet by the player
                    if player.moneyBet != nil {
                        tabMoneyPlayer[player.sit!].text = "\(player.moneyBet!)"
                    }
                    
                    //check if the player is the dealer
                    if player.isDealer == true {
                        tabImgDealer[player.sit!].hidden = false
                    }
                    
                    //set the money of the player
                    tabBtnPlayer[player.sit!].moneyLabel!.text = "\(player.money!)"
                    
                    if theTable?.object["started"] == "1" || player.bettingTurn == true {
                        actionsView?.startGameBtn.hidden = true
                    }
                    
                    //do the automatic betting if the player is small blind or big blind
                    if dealed == true && (player.moneyBet == nil || player.moneyBet! == 0) && self.table?.user?.sit! == player.sit! && player.bettingTurn == true {
                        print("checking done is bb \(player.bigBlind) or sb \(player.smallBlind)")
                        if player.bigBlind == true {
                            tabBtnPlayer[player.sit!].moneyLabel!.text = "\(player.money! - Int(theTable!.object["bb"]!)!)"
                        } else if player.smallBlind == true {
                            tabBtnPlayer[player.sit!].moneyLabel!.text = "\(player.money! - Int(theTable!.object["sb"]!)!)"
                        }
                    }
                    
                    tabMoneyPlayer[player.sit!].hidden = false
                    
                    tabBtnPlayer[player.sit!].updateContent(player, show: show)
                } else if p.header! == "centralCards" {
                    print("updating central cards")
                }

            }
        
        }
        
    }
    
    
    
    func notificationSelectedBtn(sender: UIButton) {
        // request sit when button is clicked
        let maker: XMLMaker = XMLMaker(header: "sit")
        let obj: XMLObject = XMLObject(elems: ["id":"\(table?.id)", "sit":"\(sender.tag)"], header: "table")
        
        table?.user?.sit = sender.tag
        maker.addXML(obj)
        table?.user?.send(str: maker.toString())
    }
    
    func leaveTable() {
        //request leave table
        let maker: XMLMaker = XMLMaker(header: "leave")
        let obj: XMLObject = XMLObject(elems: ["id" : "\(self.table?.user?.fd!)"], header: "player")
        
        maker.addXML(obj)
        self.table?.user?.send(str: maker.toString())

    }
    
    func startGame() {
        //request start game
        print("start game request")
        let maker: XMLMaker = XMLMaker(header: "start")
        let obj: XMLObject = XMLObject(elems: ["id" : "\(self.table?.id!)"], header: "table")
        
        maker.addXML(obj)
        print("request: \n\(maker.toString())")
        self.table?.user?.send(str: maker.toString())
    }
    
    func requestCheckFold() {
        
        print("request \(actionsView?.checkFoldBtn.titleLabel?.text)")
        if actionsView?.checkFoldBtn.titleLabel?.text == "Fold" {
            print("fold request")
            //fold request
            let maker: XMLMaker = XMLMaker(header: "fold")
            let obj: XMLObject = XMLObject(elems: ["sit":"\(table?.user?.sit!)"], header: "player")
            maker.addXML(obj)

            table?.user?.send(str: maker.toString())
            disableAllAction()
        } else {
            //check request
            requestCall()
        }
        
        timer.invalidate()
        
    }
    
    func requestCall() {
        //call request
        if theTable != nil {
            print("request Call")
            let maker: XMLMaker = XMLMaker(header: "call")
            
            var value = 0
            if let maxBet = theTable?.object["maxBet"] {
                value = Int(maxBet)!
            }

            
            if value == 0 {
                value = Int((theTable?.object["bb"])!)!
            }
            let obj: XMLObject = XMLObject(elems: ["sit":"\(table?.user?.sit!)", "moneyPut":"\(value)"], header: "player")
            
            maker.addXML(obj)
            self.table?.user?.send(str: maker.toString())
            disableAllAction()
            timer.invalidate()
            played = true
        }
    }
    
    func manualCallRequest(value: Int) {
        let maker: XMLMaker = XMLMaker(header: "call")
        let obj: XMLObject = XMLObject(elems: ["sit":"\(table?.user?.sit!)", "moneyPut":"\(value)"], header: "player")
        
        //send a manual request with a specific value
        maker.addXML(obj)
        print("manual call request :\n\(maker.toString())")
        self.table?.user?.send(str: maker.toString())
        disableAllAction()
        timer.invalidate()
        played = true
    }
    
    func requestRaise() {
        //send raise request
        print("request Raise")
        let maker: XMLMaker = XMLMaker(header: "raise")
        let obj: XMLObject = XMLObject(elems: ["sit":"\(table?.user?.sit!)", "moneyPut":(actionsView?.moneyLabel.text)!], header: "player")
        
        maker.addXML(obj)
        self.table?.user?.send(str: maker.toString())
        disableAllAction()
        timer.invalidate()
        played = true
    }
    
    
    
    func getFrameMoney(pos: Int) -> (CGPoint, CGSize) {
        
        let sizeTable: CGSize = self.tableImage!.frame.size
        let ratio: CGFloat = 7.5
        let frameBtn: CGSize = CGSizeMake(sizeTable.width / ratio, sizeTable.height / ratio)
        let sizeDiag = (3 / 4) * frameBtn.width
        let frameLabel: CGSize = CGSizeMake(60, 20)
        
        switch pos {
        case 0:
            return (CGPointMake(frameBtn.width + ratio, (sizeTable.width / 2) - (frameLabel.height / 2)), frameLabel)
        case 1:
            return (CGPointMake(sizeTable.width - frameBtn.width - ratio - frameLabel.width, (sizeTable.height / 2) - (frameLabel.height / 2)), frameLabel)
        case 2:
            return (CGPointMake((sizeTable.width / 2) - (frameLabel.width / 2), frameBtn.height + (ratio * 2)), frameLabel)
        case 3:
            return (CGPointMake((sizeTable.width / 2) - (frameLabel.width / 2), sizeTable.height - frameBtn.height - (ratio * 2) - frameLabel.height), frameLabel)
        case 4:
            return (CGPointMake(sizeDiag + frameBtn.width + ratio, sizeDiag + frameBtn.height + ratio + frameLabel.height), frameLabel)
        case 5:
            return (CGPointMake(sizeTable.width - frameBtn.width - sizeDiag - frameLabel.width, sizeTable.height - frameBtn.height - sizeDiag - (ratio * 2) - (frameLabel.height * 2)), frameLabel)
        case 6:
            return (CGPointMake(sizeDiag + frameBtn.width + ratio, sizeTable.height - frameBtn.height - sizeDiag - ratio - (frameLabel.height * 2)), frameLabel)
        case 7:
            return (CGPointMake(sizeTable.width - frameBtn.width - sizeDiag - frameLabel.width - ratio, sizeDiag + frameBtn.height + ratio + frameLabel.height), frameLabel)
        default:
            return (CGPointMake(0, 0), CGSizeMake(0, 0))
        }
    }
    
    func getFrameDealer(pos: Int) -> (CGPoint, CGSize) {
        
        let sizeTable: CGSize = self.tableImage!.frame.size
        let ratio: CGFloat = 7.5
        let frameBtn: CGSize = CGSizeMake(sizeTable.width / ratio, sizeTable.height / ratio)
        let sizeDiag = (3 / 4) * frameBtn.width
        let frameImg: CGSize = CGSizeMake(frameBtn.width / 5, frameBtn.height / 5)
        
        switch pos {
        case 0:
            return (CGPointMake(frameBtn.width + ratio, (sizeTable.width / 2) + (frameBtn.width / 2) - frameImg.height), frameImg)
        case 1:
            return (CGPointMake(sizeTable.width - frameBtn.width - ratio - frameImg.width, (sizeTable.height / 2) - (frameBtn.height / 2)), frameImg)
        case 2:
            return (CGPointMake((sizeTable.width / 2) - (frameBtn.width / 2), frameBtn.height + ratio), frameImg)
        case 3:
            return (CGPointMake((sizeTable.width / 2) + (frameBtn.width / 2) - frameImg.width, sizeTable.height - frameBtn.height - ratio - frameImg.height), frameImg)
        case 4:
            return (CGPointMake(sizeDiag + frameBtn.width - frameImg.width + ratio, sizeDiag + frameBtn.height + frameImg.height + ratio), frameImg)
        case 5:
            return (CGPointMake(sizeTable.width - frameBtn.width - sizeDiag, sizeTable.height - frameBtn.height - sizeDiag - (ratio * 2) - (frameImg.height * 2)), frameImg)
        case 6:
            return (CGPointMake(sizeDiag + frameBtn.width + frameImg.width + ratio, sizeTable.height - frameBtn.height - sizeDiag - ratio), frameImg)
        case 7:
            return (CGPointMake(sizeTable.width - frameBtn.width - sizeDiag - (frameImg.width * 2) - ratio, sizeDiag + frameBtn.height - frameImg.height + ratio), frameImg)
        default:
            return (CGPointMake(0, 0), CGSizeMake(0, 0))
        }
    }
    
    func getFrameBtn(pos: Int) -> (CGPoint, CGSize) {
        
        let sizeTable: CGSize = self.tableImage!.frame.size
        let ratio: CGFloat = 7.5
        let frameBtn: CGSize = CGSizeMake(sizeTable.width / ratio, sizeTable.height / ratio)
        let sizeDiag = (3 / 4) * frameBtn.width
        
        switch pos{
        case 0: //left
            return (CGPointMake(0, (sizeTable.width / 2) - (frameBtn.width / 2)), frameBtn)
        case 1: // right
            return (CGPointMake(sizeTable.width - frameBtn.width, (sizeTable.height / 2) - (frameBtn.height / 2)), frameBtn)
        case 2: //top
            return (CGPointMake((sizeTable.width / 2) - (frameBtn.width / 2), 0), frameBtn)
        case 3: //bottom
            return (CGPointMake((sizeTable.width / 2) - (frameBtn.width / 2), sizeTable.height - frameBtn.height), frameBtn)
        case 4: //top-left
            return (CGPointMake(sizeDiag, sizeDiag), frameBtn)
        case 5: // bottom-right
            return (CGPointMake(sizeTable.width - frameBtn.width - sizeDiag, sizeTable.height - frameBtn.height - sizeDiag), frameBtn)
        case 6: //bottom-left
            return (CGPointMake(sizeDiag, sizeTable.height - frameBtn.height - sizeDiag), frameBtn)
        case 7: //top-right
            return (CGPointMake(sizeTable.width - frameBtn.width - sizeDiag, sizeDiag), frameBtn)
        default:
            return (CGPointMake(0, 0), CGSizeMake(0, 0))
        }
    }
    
    override func shouldAutorotate() -> Bool {
        return false
    }
    
}

