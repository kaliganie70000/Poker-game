//
//  ViewBtnSit.swift
//  PokerGameClient
//
//  Created by Antoine roy on 24/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class ViewBtnSit: UIView {

    //@IBOutlet weak var btnSit: UIButton!
    var btnSit: UIButton = UIButton()
    
    class func instanceFromNib() -> ViewBtnSit {
        
        //init the view
        return UINib(nibName: "ViewBtnSit", bundle: nil).instantiateWithOwner(nil, options: nil)[0] as! ViewBtnSit
        
    }
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.frame = frame
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        //fatalError("init(coder:) has not been implemented")
    }
    
    func createContent() {
        //create the content of the view
        btnSit.frame = self.frame
        btnSit.setBackgroundImage(UIImage(named: "icnSit"), forState: .Normal)
        self.addSubview(btnSit)
    }
    
    


}
