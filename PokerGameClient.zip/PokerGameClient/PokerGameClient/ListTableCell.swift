//
//  ListTableCell.swift
//  PokerGameClient
//
//  Created by Antoine roy on 23/06/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class ListTableCell: UITableViewCell {

    @IBOutlet weak var tableNameLabel: UILabel!
    @IBOutlet weak var tablePlayersLabel: UILabel!
    @IBOutlet weak var tableBlindLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
