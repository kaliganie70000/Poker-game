//
//  PokerGameClientUITests.swift
//  PokerGameClientUITests
//
//  Created by Antoine roy on 21/08/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import XCTest

class PokerGameClientUITests: XCTestCase {
        
    override func setUp() {
        super.setUp()
        
        continueAfterFailure = false
        XCUIApplication().launch()

    }
    
    func testCreateTable() {
        
        //before to use, please change manually the content of the field 'ipTextField'. This can be found in the file "ConnectionViewController.swift".
        
        let app = XCUIApplication()
        app.buttons["btnCreate"].tap()
        app.otherElements.containingType(.Image, identifier:"logo_kent").childrenMatchingType(.Other).elementBoundByIndex(2).childrenMatchingType(.TextField).elementBoundByIndex(0).tap()
        app.buttons["FieldBlind"].tap()
        app.tables.staticTexts["medium blind"].tap()
        
        let button = app.buttons["+"]
        button.tap()
        button.tap()
        app.buttons["Create Table"].tap()
        sleep(2)
        app.buttons["Leave Table"].tap()

    }
    
    override func tearDown() {
        super.tearDown()
    }
    
    
}
